package com.monfox.client;

import monfox.stack.chief.csm.CSM_MESSAGE;

public interface SessionClient {

    CSM_MESSAGE sessionRequest(CSM_MESSAGE sessionRequest) throws SessionException;

    void endSession() throws SessionException;

    void disconnect();

    byte[] sendDataSession(String id,
        boolean simForced,
        byte[] data) throws SessionException;

}
