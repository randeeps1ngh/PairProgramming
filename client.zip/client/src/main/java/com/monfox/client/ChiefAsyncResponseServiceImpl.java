package com.monfox.client;

import java.util.Optional;
import java.util.concurrent.atomic.AtomicInteger;
import lombok.extern.slf4j.Slf4j;
import monfox.stack.chief.csm.CSMSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class ChiefAsyncResponseServiceImpl implements ChiefAsyncResponseService {

    private final SessionClientImpl client;

    @Autowired
    ChiefAsyncResponseServiceImpl(SessionClientImpl client) {
        this.client = client;
    }

    private AtomicInteger retry = new AtomicInteger(0);

    /**
     * Send decleration data to CHIEF
     */
    @Override
    public byte[] sendAsyncResponse(byte[] data) throws SessionException {
        //@TODO: Must Session Client Factory to produce mulitple session

        System.out.println("client session " + Optional.ofNullable(this.client.session).isPresent());

        if(Optional.ofNullable(this.client.session).isPresent()) {
            System.out.println("client session status " + (this.client.session.getConnectionStatus()
                == CSMSession.STATUS_NOT_CONNECTED));
        }

        if (!Optional.ofNullable(this.client.session).isPresent()
            || this.client.session.getConnectionStatus() == CSMSession.STATUS_NOT_CONNECTED) {

         //   if(retry.getAndIncrement() == 0) {
                System.out.println("initialize is invoked");
                this.client.initialize();
           // }
        }
        System.out.println("sending data to server");


        return client.sendDataSession("SESSION", false, data);
    }
}
