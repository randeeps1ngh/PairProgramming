package com.monfox.client;

import lombok.Getter;

/**
 * Session Client Exception
 */
@Getter
public class SessionException extends Exception {

    /** serialVersionUID. */
    private static final long serialVersionUID = 1L;

    private Exception cause;
    private byte reason;

    SessionException(String msg) {
        super(msg);
    }

    SessionException(String msg, Exception cause) {
        super(msg);
        this.cause = cause;
    }

    SessionException(String msg, byte reason) {
        super(msg);
        this.reason = reason;
    }
}
