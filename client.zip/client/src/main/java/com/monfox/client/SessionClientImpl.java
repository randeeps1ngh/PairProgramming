package com.monfox.client;

import java.net.InetAddress;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import monfox.stack.chief.csm.ABORT_SESSION;
import monfox.stack.chief.csm.CSMRawClientSession;
import monfox.stack.chief.csm.CSMSession;
import monfox.stack.chief.csm.CSM_MESSAGE;
import monfox.stack.chief.csm.DATA;
import monfox.stack.chief.csm.END_SESSION;
import monfox.stack.chief.csm.FORCED_END_SESSION;
import monfox.stack.chief.csm.START_SESSION_REQUEST;
import monfox.stack.chief.csm.START_SESSION_RESPONSE;
import monfox.stack.osi.api.ProtocolException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;


@Component
@Slf4j
@Scope(value = "prototype")
public class SessionClientImpl implements SessionClient {

    private SessionClientProperties configuration;

    @Getter
    @Setter
    public CSMRawClientSession session;

    private START_SESSION_REQUEST sessionRequest;

    @Autowired
    SessionClientImpl(SessionClientProperties configuration) {
        this.configuration = configuration;
        this.sessionRequest = new START_SESSION_REQUEST();
    }


    private SessionClientImpl(byte[] clientTsel, byte[] serverTsel,
        byte[] clientSsel, byte[] serverSsel,
        String host, int port) throws SessionException {
        try {
            session = new CSMRawClientSession(
                clientTsel,
                serverTsel,
                InetAddress.getByName(host),
                port,
                clientSsel,
                serverSsel);

            session.getConnectParams().setSoTimeout(4777);
            session.getConnectParams().setKeepAlive(true);

            session.setRequestedTPDUSize(7);
        } catch (Exception e) {
            throw new SessionException("cannot create core session object", e);
        }
    }

    /**
     *
     * @param clientTsel clientTsel
     * @param serverTsel serverTsel
     * @param clientSsel clientSsel
     * @param serverSsel serverSsel
     * @param host hostName
     * @param port portNumber
     * @throws SessionException SessionException
     */
    private void createRawSession(byte[] clientTsel, byte[] serverTsel,
                                  byte[] clientSsel, byte[] serverSsel,
                                  String host, int port) throws SessionException {
        try {
            this.session = new CSMRawClientSession(
                    clientTsel,
                    serverTsel,
                    InetAddress.getByName(host),
                    port,
                    clientSsel,
                    serverSsel);

            this.session.setRequestedTPDUSize(7);
        } catch (Exception e) {
            throw new SessionException("cannot create core session object", e);
        }
    }

    @Override
    public void endSession() throws SessionException {

        try {
            END_SESSION esReq = new END_SESSION();
            session.send(esReq);
        } catch (Exception ex) {
            throw new SessionException("SEND FAILED: " + ex, ex);
        }
    }

    /*private void forceEndSession() throws SessionException {

        try {
            FORCED_END_SESSION esReq = new FORCED_END_SESSION();
            session.send(esReq);
        } catch (Exception ex) {
            throw new SessionException("SEND FAILED: " + ex.getMessage(), ex);
        }
    }*/

    @Override
    public void disconnect() {
        log.debug("Disconnecting");
        session.tDisconnect();
    }

    @Override
    public CSM_MESSAGE sessionRequest(CSM_MESSAGE sessionRequest)
        throws SessionException {



        if (session.getConnectionStatus() == CSMSession.STATUS_CONNECTED) {
            try {
                session.send(sessionRequest);
            } catch (Exception ex) {
                throw new SessionException("SEND START-SESSION FAILED (" + ex.getMessage() + ")", ex);
            }

            try {
                CSM_MESSAGE response = session.receive();

                if (response instanceof START_SESSION_RESPONSE) {

                    START_SESSION_RESPONSE ssResponse = (START_SESSION_RESPONSE) response;

                    if (ssResponse.getResult() != 0) {
                        throw new StartSessionFailedException(ssResponse.getResult());
                    }
                    return ssResponse;
                } else if (response instanceof ABORT_SESSION) {
                    ABORT_SESSION as = (ABORT_SESSION) response;

                    throw new AbortSessionException(as.getReason());
                } else {
                    throw new SessionException("INVALID RESPONSE MESSAGE: " + response);
                }
            } catch (monfox.stack.osi.api.CommunicationsException e) {
                throw new SessionException("COMMUNICATIONS ERROR ON RECEIVE (" + e.getMessage() + ")", e);
            }
        } else {
            throw new SessionException("COMMUNICATIONS ERROR ON RECEIVE");
        }
    }

    /**
     * Sends data to CHIEF.
     *
     * @param data byte[]
     * @return byte[] - byte array
     * @throws SessionException Exception
     */
    public byte[] sendDataChief(byte[] data) throws SessionException {
        DATA msg = new DATA();
        msg.setBytes(data);

        try {
            session.setSocketConnectTimeoutMillis(2000);
            session.send(msg);
           // session.send(msg,timeout);

        } catch (Exception ex) {
            throw new SessionException("SEND FAILED: " + ex, ex);
        }

        try {
            CSM_MESSAGE rsp = session.receive();
            if (rsp instanceof FORCED_END_SESSION) {
                FORCED_END_SESSION fes = (FORCED_END_SESSION) rsp;
                throw new ForcedEndSessionException(fes.getReason());
            } else if (rsp instanceof ABORT_SESSION) {
                ABORT_SESSION as = (ABORT_SESSION) rsp;
                throw new AbortSessionException(as.getReason());
            } else if (rsp instanceof DATA) {
                return ((DATA) rsp).getBytes();
            } else {
                throw new SessionException("INVALID RESPONSE: " + rsp);
            }
        } catch (monfox.stack.osi.api.CommunicationsException e) {
            throw new SessionException("COMMUNICATIONS ERROR ON RECEIVE (" + e + ")", e);
        }
    }

    /**
     * Start the START_SESSION_REQUEST based on DES111
     */
    private START_SESSION_REQUEST setSessionRequest() {
        START_SESSION_REQUEST sessionRequest = new START_SESSION_REQUEST();
        sessionRequest.setIndividual("ANY".getBytes());
        sessionRequest.setLocation(this.configuration.getLocation()
                .getBytes());
        sessionRequest.setPurpose((byte) 0x4f); // Set the purpose to O
        sessionRequest.setVersion((byte) 1);
        sessionRequest.setRole(this.configuration.getRole()
                .getBytes());
        sessionRequest.setSSUserReference(this.configuration.getSponsor().getBytes());
        return sessionRequest;
    }

    /**
     *
     * @throws SessionException SessionException
     */
    private void setSessionRequestInit() throws SessionException {
        this.sessionRequest.setIndividual("ANY".getBytes());
        sessionRequest.setLocation(this.configuration.getLocation()
                .getBytes());
        sessionRequest.setPurpose((byte) 0x4f); // Set the purpose to O
        sessionRequest.setVersion((byte) 1);
        sessionRequest.setRole(this.configuration.getRole()
                .getBytes());
        sessionRequest.setSSUserReference(this.configuration.getSponsor().getBytes());
        try {
            if (session.getConnectionStatus() == CSMSession.STATUS_NOT_CONNECTED) {
                session.tConnect();
            }
        } catch (ProtocolException e) {
            throw new SessionException("PROTOCOL ERROR (" + e.getMessage() + ")", e);
        } catch (Exception e) {
            throw new SessionException("GENERAL ERROR (" + e.getMessage() + ")", e);
        }
    }

    /**
     *Sends data based on session ID.
     *
     * @param id Id of current Session
     * @param simForced - Monfox Sim Forced
     * @param data - Edifact data
     * @return Response data
     * @throws SessionException - Session Exception
     */
    @Override
    public byte[] sendDataSession(String id ,
                           boolean simForced ,
                           byte[] data) throws SessionException {
        byte[] rspData;
        try {
            log.debug("-- [" + id + "][BEGIN: SIMPLE-TRANSACTION] --");



            rspData = this.sendDataChief(data);

            System.out.println("INCOMING MESSAGE" + new String(rspData));
            log.debug("INCOMING MESSAGE", new String(rspData));

        } finally {
            log.debug("-- [" + id + "][END: SIMPLE-TRANSACTION] --");
        }
        return rspData;
    }

    /**
     * This will initialize
     * @throws SessionException - Session Exception
     */
    public void initialize() throws SessionException {
        this.createRawSession(
                this.configuration.calculateLocalTsel(), this.configuration.calculateServerTsel(),
                this.configuration.calculateLocalTsel(), this.configuration.calculateServerTsel(),
                this.configuration.getServerHost(), this.configuration.getServerPort());
        this.setSessionRequestInit();
        //login into CHIEF once.
        this.sessionRequest(setSessionRequest());
        //this,sessionRequest(setSessionRequest());

    }

}
