package com.monfox.client;

/**
 * Start Session Failed Exception
 */
class StartSessionFailedException extends SessionException {

    /** serialVersionUID. */
    private static final long serialVersionUID = 1L;

    StartSessionFailedException(byte reason) {
        super("StartSessionFailed", reason);
    }
}