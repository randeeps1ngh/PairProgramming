package com.monfox.client;

/**
 * Abort Session Exception
 */
class AbortSessionException extends SessionException {

    /** serialVersionUID. */
    private static final long serialVersionUID = 1L;

    AbortSessionException(byte reason) {
        super("AbortSession", reason);
    }
}