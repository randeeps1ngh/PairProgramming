package com.monfox.client;

import java.util.Random;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;


@Component
@Slf4j
public class AsyncSessionProcessor {

    @Autowired
    private ChiefAsyncResponseService chiefAsyncResponseService;


    @Scheduled(fixedRate = 600000)
    public void run() {

        try {

            String responseData = "hello";
            chiefAsyncResponseService.sendAsyncResponse(responseData.getBytes());

        } catch (Exception e) {
            log.error("Exception caught", e);
        }
    }

}