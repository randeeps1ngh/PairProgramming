package com.monfox.client;

/**
 * Forced End Session Exception
 */
class ForcedEndSessionException extends SessionException {

    /** serialVersionUID. */
    private static final long serialVersionUID = 1L;

    ForcedEndSessionException(byte reason) {
        super("ForcedEndSession", reason);
    }
}

