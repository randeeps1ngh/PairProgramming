package com.monfox.client;

import java.io.IOException;
import org.xml.sax.SAXException;

public interface ChiefAsyncResponseService {

    byte[] sendAsyncResponse(byte[] data) throws SessionException, IOException, SAXException;
}
