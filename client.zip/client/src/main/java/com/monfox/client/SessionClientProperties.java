package com.monfox.client;


import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Data
@Configuration
@ConfigurationProperties(prefix = "cam.monfox.dosi.client")
public class SessionClientProperties {

    private int serverPort;

    private String serverHost;

    private int[] localTsel;

    private int[] serverTsel;

    private String role;

    private String location;

    private String sponsor = "UKCHIEFSPONSOR";

    private Boolean debug;

    protected byte[] calculateLocalTsel() {
        //Need better way to convert
        byte[] localBTsel = new byte[localTsel.length];
        for (int i = 0; i < localTsel.length; i++) {
            localBTsel[i] = (byte) localTsel[i];
        }
        return localBTsel;
    }

    protected byte[] calculateServerTsel() {
        //Need better way to convert
        byte[] serverBTsel = new byte[serverTsel.length];
        for (int i = 0; i < serverTsel.length; i++) {
            serverBTsel[i] = (byte) serverTsel[i];
        }
        return serverBTsel;
    }
}
