package com.monfox.server;


import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Data
@Configuration
@ConfigurationProperties(prefix = "cam.monfox.dosi.server")
public class SessionServerProperties {

    private int port;

    private String host;

    private int[] tsel;

    private Boolean debug;

    /**
     * Generates configuration in bytes
     */
    public byte[] calculateTsel() {
        //Need better way to convert
        byte[] btsel = new byte[tsel.length];
        for (int i = 0; i < tsel.length; i++) {
            btsel[i] = (byte) tsel[i];
        }
        return btsel;
    }
}
