package com.monfox.server;

import java.util.concurrent.atomic.AtomicInteger;
import lombok.extern.slf4j.Slf4j;
import monfox.stack.chief.csm.ABORT_SESSION;
import monfox.stack.chief.csm.CSMRawServerSession;
import monfox.stack.chief.csm.CSM_MESSAGE;
import monfox.stack.chief.csm.CoderException;
import monfox.stack.chief.csm.DATA;
import monfox.stack.chief.csm.END_SESSION;
import monfox.stack.chief.csm.FORCED_END_SESSION;
import monfox.stack.chief.csm.RESTART_SESSION_REQUEST;
import monfox.stack.chief.csm.RESTART_SESSION_RESPONSE;
import monfox.stack.chief.csm.SESSION_STATUS;
import monfox.stack.chief.csm.START_SESSION_REQUEST;
import monfox.stack.chief.csm.START_SESSION_RESPONSE;
import monfox.stack.osi.api.CommunicationsException;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * Session processor which process each incoming message from CHIEF and handle it in seperate Thread
 */
@Slf4j
@SuppressWarnings("PMD.DoNotUseThreads")

public class SessionProcessor extends Thread {

    private final CSMRawServerSession session;

    @Autowired
    private final ChiefResponseGenerator chiefResponseGenerator = new ChiefResponseGenerator();

    /**
     * Constructor
     * @param sess - DOSI CSMRawServerSession
     */
    public SessionProcessor(CSMRawServerSession sess) {
        this.session = sess;
    }


    /**
     * Run the thread.
     */
    public void run() {
        try {
            while (true) {

                int restartCount = 0;
                CSM_MESSAGE msg = session.receive();

                log.info("RECEIVED: " + msg);
                if (msg instanceof START_SESSION_REQUEST) {
                    log.info(">> START-SESSION-REQUEST " + msg);

                    START_SESSION_RESPONSE rsp = new START_SESSION_RESPONSE();

                    // -- insert purpose as result in order to allow triggering of
                    // -- a failed START SESSION REQUEST
                    rsp.setResult((byte) 0);
                    rsp.setClientSessionReference("".getBytes());
                    log.info("<< START-SESSION-RESPONSE " + rsp);
                    if(restartCount == 1){
                        Thread.sleep(200000);
                    }

                    session.send(rsp);
                } else if (msg instanceof RESTART_SESSION_REQUEST) {
                    RESTART_SESSION_REQUEST req = (RESTART_SESSION_REQUEST) msg;
                    log.info(" >> RESTART-SESSION-REQUEST: " + msg);

                    RESTART_SESSION_RESPONSE rsp = new RESTART_SESSION_RESPONSE();
                    rsp.setResult(req.getPurpose());
                    rsp.setMaxTSDUSizeResp(req.getMaxTSDUSizeResp() + 1);
                    rsp.setMaxTSDUSizeInit(req.getMaxTSDUSizeInit() + 1);
                    rsp.setSSUserReference(req.getSSUserReference());
                    rsp.setCommonReference(req.getCommonReference());
                    log.info(" << RESTART-SESSION-RESPONSE: " + rsp);

                    session.send(rsp);
                } else if (msg instanceof END_SESSION) {
                    END_SESSION req = (END_SESSION) msg;
                    log.info(" >> END-SESSION: " + req);
                } else if (msg instanceof ABORT_SESSION) {
                    ABORT_SESSION req = (ABORT_SESSION) msg;
                    log.info(" >> ABORT-SESSION: " + req);
                } else if (msg instanceof DATA) {
                    DATA req = (DATA) msg;
                    log.debug(" >> INCOMING DATA: " + req);
                    System.out.println(" >> INCOMING DATA: " + req);

                    String data = new String(req.getBytes());

                    if (data.contains("forced-end")) {
                        FORCED_END_SESSION fes = new FORCED_END_SESSION();
                        fes.setReason((byte) 1);
                        log.debug(" << FORCED-END-SESSION: " + fes);
                        session.send(fes);
                    } else {

                        DATA response = chiefResponseGenerator.generateResponse(req);
                        session.send(response);
                      //  Thread.sleep(10000);
                       // session.tDisconnect();
                        log.debug(" << OUTGOING DATA: " + response);
                    }
                } else if (msg instanceof SESSION_STATUS) {
                    SESSION_STATUS req = (SESSION_STATUS) msg;
                    log.info(" >> SESSION-STATUS: " + req);

                    SESSION_STATUS rsp = new SESSION_STATUS();
                    rsp.setTransactionIdentifier(req.getTransactionIdentifier());
                    rsp.setTransactionStatus((byte) 123);
                    rsp.setTransactionLevel((byte) 100);
                    rsp.setInventoryConsReference(req.getInventoryConsReference());

                    log.info(" << SESSION-STATUS: " + rsp);

                    session.send(rsp);
                } else {
                    log.info("unsupported message:" + msg);
                }
            }
        } catch (CommunicationsException | CoderException | InterruptedException e) {
            log.error(e.getClass().getCanonicalName() + e);
        }
    }


}
