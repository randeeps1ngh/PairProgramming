package com.monfox.server;

import lombok.extern.slf4j.Slf4j;
import monfox.stack.chief.csm.DATA;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class ChiefResponseGenerator {

    public ChiefResponseGenerator() {
    }

    public DATA generateResponse(DATA req) {
        String request = new String(req.getBytes());
        DATA response = new DATA();
        try {

            response = new DATA(new String(request + " reply").getBytes());

            //check and add delay
            int randomDelay = 120000;

            log.info("Delaying response by {} ms", randomDelay);
            Thread.sleep(randomDelay);
        } catch (Exception e) {
            log.error("Exception occurred - can't generate response for the message", e);
        }
        return response;
    }


}
