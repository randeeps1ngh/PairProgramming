package com.monfox.server;

import java.io.IOException;
import java.net.UnknownHostException;
import lombok.extern.slf4j.Slf4j;
import monfox.stack.osi.api.FactoryException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class SessionApplicationListener {

    private final SessionServer server;

    @Autowired
    SessionApplicationListener(SessionServerProperties configuration)
        throws FactoryException, UnknownHostException {

        this.server = new SessionServer(configuration);
    }

    @EventListener
    public void onApplicationEvent(ContextRefreshedEvent event) {
        try {
            this.server.startUp();
        } catch (IOException e) {
            log.error("Unable to start Server " + e.getMessage(), e);
        }
    }
}