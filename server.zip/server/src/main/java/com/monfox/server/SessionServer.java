package com.monfox.server;

import java.io.IOException;
import java.net.UnknownHostException;
import lombok.extern.slf4j.Slf4j;
import monfox.stack.chief.csm.CSMRawServerSession;
import monfox.stack.osi.api.FactoryException;
import monfox.stack.osi.session.S_EntityParams;
import monfox.stack.osi.transport.TAPI;
import monfox.stack.osi.transport.TConnection;
import monfox.stack.osi.transport.TSAP;
import monfox.stack.osi.transport.T_EntityParams;
import monfox.stack.osi.transport.rfc1006.RFC1006_N_EntityParams;
import org.springframework.stereotype.Component;

/**
 * SessionServer implements the DOSI TSAP listener class on current thread.
 */
@Slf4j
@Component
@SuppressWarnings("PMD.DoNotUseThreads")
public class SessionServer implements TSAP.Listener {


    private final SessionServerProperties configuration;

    protected TSAP tsap;
    protected final S_EntityParams localSParams;

    /**
     * Constructor
     * @param configuration - Spring configuration
     * @throws UnknownHostException - java.net.UnknownHostException
     * @throws FactoryException - DOSI Exception
     */
    public SessionServer(SessionServerProperties configuration)
        throws UnknownHostException, FactoryException {
        this.configuration = configuration;
        this.tsap = this.buildTapiConfiguration();

        S_EntityParams localSParams = new S_EntityParams();
        localSParams.setSSelector(configuration.calculateTsel());
        this.localSParams = localSParams;
    }

    /**
     * Start up listening server
     */
    public void startUp() throws IOException {
        tsap.startListening();
        log.info("-- LISTENING -- : {} ", tsap.getFullAddressString());
    }

    /**
     * Build TSAP Configuration.
     */
    private TSAP buildTapiConfiguration() throws UnknownHostException, FactoryException {
        T_EntityParams localTParams;

        localTParams = new T_EntityParams();
        localTParams.setTSelector(this.configuration.calculateTsel());

        RFC1006_N_EntityParams rfc1006Params = new RFC1006_N_EntityParams();
        rfc1006Params.setInetAddress(this.configuration.getHost());
        rfc1006Params.setPort(this.configuration.getPort());
        rfc1006Params.setKeepAlive(true);
        rfc1006Params.setSoTimeout(3456);

        TAPI tapi = new TAPI();
        tsap = tapi.newTSAP(localTParams, rfc1006Params);
        tsap.setListener(this);
        tsap.setTPDUSizeCode((byte) 0x07); // Hard wire as its working this way

        log.debug("Configuration of server set up");
        return tsap;
    }

    /**
     * This component will add as server and will add the connection to Thread.
     * @param conn - Tconnection
     */
    public void connectionAdded(TConnection conn) {
        log.debug("\nNEW CONNECTION: " + conn + "\nTPDU-SIZE" + conn.getTPDUSizeCode());

        CSMRawServerSession sess = new CSMRawServerSession(conn,
            this.localSParams.getSSelector(),
            "".getBytes());

        SessionProcessor proc = new SessionProcessor(sess);
        proc.start();

    }

    public void connectionRemoved(TConnection conn) {
        log.info("\nCONNECTION REMOVED: " + conn);
    }
}
